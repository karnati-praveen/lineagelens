#!/usr/bin/env bash
# ============================================================
#  LineageLens — Pre-Deployment Test Script (pratry.sh)
#  Usage:
#    bash pratry.sh           # test all tiers
#    bash pratry.sh base      # test only base
#    bash pratry.sh plus      # test only plus
#    bash pratry.sh max       # test only max
# ============================================================
set -euo pipefail

TIER="${1:-all}"
BASE_URL="http://localhost:8787"
PROXY_URL="http://localhost:8788"
COMPOSE_DIR="$(cd "$(dirname "$0")/deploy" && pwd)"
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

pass() { echo -e "${GREEN}  PASS${NC}  $1"; }
fail() { echo -e "${RED}  FAIL${NC}  $1"; FAILURES=$((FAILURES+1)); }
info() { echo -e "${CYAN}  ----${NC}  $1"; }
section() { echo -e "\n${YELLOW}══════════════════════════════════════${NC}"; echo -e "${YELLOW}  $1${NC}"; echo -e "${YELLOW}══════════════════════════════════════${NC}"; }

FAILURES=0
TOKEN=""
REFRESH_TOKEN=""
RECORD_ID=""

# ──────────────────────────────────────────────────────────────
# 0. PREREQUISITES
# ──────────────────────────────────────────────────────────────
section "0. Prerequisites"

check_cmd() {
  command -v "$1" &>/dev/null && pass "$1 found" || fail "$1 NOT installed"
}
check_cmd docker
check_cmd curl
check_cmd python3

if docker info &>/dev/null 2>&1; then
  pass "Docker daemon running"
else
  fail "Docker daemon not running — start Docker Desktop first"
  exit 1
fi

if docker compose version &>/dev/null 2>&1; then
  COMPOSE_CMD="docker compose"
  pass "docker compose v2 found"
elif docker-compose version &>/dev/null 2>&1; then
  COMPOSE_CMD="docker-compose"
  pass "docker-compose v1 found"
else
  fail "No docker compose found"
  exit 1
fi

# ──────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────

wait_for_backend() {
  info "Waiting for backend (up to 60s)..."
  for i in $(seq 1 60); do
    curl -sf "$BASE_URL/health" &>/dev/null && { pass "Backend up after ${i}s"; return 0; }
    sleep 1
  done
  fail "Backend did not start within 60s"
  return 1
}

# Register + login. Sets TOKEN and REFRESH_TOKEN.
# Uses JSON body and reads camelCase accessToken from response.
register_and_login() {
  local user="pratryuser_$(date +%s)"
  local pass="Pratry$ecret1!"

  info "Registering user: $user"
  local reg
  reg=$(curl -sf -X POST "$BASE_URL/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"username\":\"$user\",\"password\":\"$pass\",\"workspaceId\":\"pratry-workspace\"}" 2>&1) || {
      fail "Register request failed: $reg"; return 1
    }
  echo "$reg" | grep -q "accessToken" && pass "Registered — token in response" || {
    fail "Register unexpected response: $reg"; return 1
  }

  info "Logging in as $user (JSON body)..."
  local login
  login=$(curl -sf -X POST "$BASE_URL/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"username\":\"$user\",\"password\":\"$pass\"}" 2>&1) || {
      fail "Login request failed"; return 1
    }

  # Response key is camelCase accessToken — NOT access_token
  TOKEN=$(echo "$login" | python3 -c "import sys,json; print(json.load(sys.stdin)['accessToken'])" 2>/dev/null)
  REFRESH_TOKEN=$(echo "$login" | python3 -c "import sys,json; print(json.load(sys.stdin)['refreshToken'])" 2>/dev/null)

  [[ -n "$TOKEN" ]] && pass "Token obtained (accessToken)" || {
    fail "No accessToken in login response: $login"; return 1
  }
}

ingest_record() {
  info "Ingesting test record..."
  local resp
  resp=$(curl -sf -X POST "$BASE_URL/ingest" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
      "agent":"copilot",
      "prompt":"Write a JWT validation function",
      "response":"def validate(t): return jwt.decode(t, SECRET)",
      "model":"gpt-4o",
      "workspace_id":"pratry-workspace",
      "file_path":"src/auth/jwt.py",
      "git_commit":"abc123",
      "risk_level":"HIGH"
    }' 2>&1) || { fail "Ingest failed: $resp"; return 1; }

  RECORD_ID=$(echo "$resp" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])" 2>/dev/null)
  [[ -n "$RECORD_ID" ]] && pass "Record ingested: $RECORD_ID" || { fail "No id in ingest response: $resp"; return 1; }
}

# ──────────────────────────────────────────────────────────────
# INDIVIDUAL TESTS
# ──────────────────────────────────────────────────────────────

test_health() {
  section "Health"
  local h; h=$(curl -sf "$BASE_URL/health" 2>&1) || { fail "Health unreachable"; return; }
  echo "$h" | grep -q '"status":"ok"' && pass "status: ok" || fail "status not ok: $h"
  echo "$h" | grep -q "productMode"  && pass "productMode present" || fail "productMode missing"
  info "$h"
}

test_auth() {
  section "Auth"
  register_and_login

  # Token refresh
  if [[ -n "$REFRESH_TOKEN" ]]; then
    local ref
    ref=$(curl -sf -X POST "$BASE_URL/auth/refresh" \
      -H "Content-Type: application/json" \
      -d "{\"refreshToken\":\"$REFRESH_TOKEN\"}" 2>&1) || { fail "Refresh failed"; }
    echo "$ref" | grep -q "accessToken" && pass "Token refresh works" || fail "Refresh bad response: $ref"
  fi

  # Reject bad token
  local code
  code=$(curl -so /dev/null -w "%{http_code}" "$BASE_URL/provenance/00000000-0000-0000-0000-000000000001" \
    -H "Authorization: Bearer totally.invalid.token" 2>/dev/null)
  [[ "$code" =~ ^(401|403|422)$ ]] && pass "Bad token rejected (HTTP $code)" || fail "Bad token NOT rejected (HTTP $code)"

  # Reject no token
  code=$(curl -so /dev/null -w "%{http_code}" "$BASE_URL/export/audit" 2>/dev/null)
  [[ "$code" =~ ^(401|403|422)$ ]] && pass "No token rejected (HTTP $code)" || fail "No token NOT rejected (HTTP $code)"
}

test_ingest() {
  section "Ingest"
  ingest_record

  # Missing required field
  local code
  code=$(curl -so /dev/null -w "%{http_code}" -X POST "$BASE_URL/ingest" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"agent":"test"}' 2>/dev/null)
  [[ "$code" == "422" ]] && pass "Incomplete ingest rejected (422)" || fail "Incomplete ingest returned $code"
}

test_provenance() {
  section "Provenance"
  [[ -z "$RECORD_ID" ]] && { info "No record ID — skip"; return; }
  local r
  r=$(curl -sf "$BASE_URL/provenance/$RECORD_ID" -H "Authorization: Bearer $TOKEN" 2>&1) || { fail "Fetch failed"; return; }
  echo "$r" | grep -q "$RECORD_ID" && pass "Record fetched" || fail "Record ID missing in response"

  local code
  code=$(curl -so /dev/null -w "%{http_code}" "$BASE_URL/provenance/00000000-0000-0000-0000-000000000000" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null)
  [[ "$code" == "404" ]] && pass "Non-existent record → 404" || fail "Expected 404, got $code"
}

test_search() {
  section "Search"
  local r
  r=$(curl -sf -X POST "$BASE_URL/search" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"query":"JWT validation","limit":5}' 2>&1) || { fail "Search failed: $r"; return; }
  python3 -c "import sys,json; json.loads(sys.argv[1])" "$r" 2>/dev/null && pass "Search returns valid JSON" || fail "Search bad JSON: $r"
}

test_insights() {
  section "Insights"
  local r
  r=$(curl -sf -X POST "$BASE_URL/insights/dashboard" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"days":30}' 2>&1) || { fail "Insights failed: $r"; return; }
  python3 -c "import sys,json; json.loads(sys.argv[1])" "$r" 2>/dev/null && pass "Insights returns valid JSON" || fail "Insights bad JSON: $r"
}

test_export() {
  section "Export"
  local code
  code=$(curl -so /dev/null -w "%{http_code}" "$BASE_URL/export/audit" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null)
  [[ "$code" == "200" ]] && pass "Export returns 200" || fail "Export returned $code"

  code=$(curl -so /dev/null -w "%{http_code}" "$BASE_URL/export/audit" 2>/dev/null)
  [[ "$code" =~ ^(401|403|422)$ ]] && pass "Export without auth rejected ($code)" || fail "Export without auth NOT rejected ($code)"
}

test_dashboard_page() {
  section "Dashboard HTML"
  local code
  code=$(curl -so /dev/null -w "%{http_code}" "$BASE_URL/dashboard" 2>/dev/null)
  [[ "$code" == "200" ]] && pass "Dashboard page returns 200" || fail "Dashboard page returned $code"
  curl -sf "$BASE_URL/dashboard" 2>/dev/null | grep -qi "<!DOCTYPE" && pass "Response is HTML" || fail "Response not HTML"
}

test_security_headers() {
  section "Security Headers"
  local h; h=$(curl -sI "$BASE_URL/health" 2>/dev/null)
  echo "$h" | grep -qi "x-content-type-options" && pass "x-content-type-options present" || fail "x-content-type-options MISSING"
  echo "$h" | grep -qi "x-frame-options"         && pass "x-frame-options present"         || fail "x-frame-options MISSING"
  echo "$h" | grep -qi "referrer-policy"          && pass "referrer-policy present"          || fail "referrer-policy MISSING"
}

test_team() {
  section "Team API"
  local r
  r=$(curl -sf "$BASE_URL/team/members" -H "Authorization: Bearer $TOKEN" 2>&1) || { fail "Team members failed: $r"; return; }
  python3 -c "import sys,json; json.loads(sys.argv[1])" "$r" 2>/dev/null && pass "Team members returns valid JSON" || fail "Team members bad JSON: $r"

  local code
  code=$(curl -so /dev/null -w "%{http_code}" -X POST "$BASE_URL/team/invite" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"email":"not-an-email"}' 2>/dev/null)
  [[ "$code" =~ ^(400|422)$ ]] && pass "Invalid invite email rejected ($code)" || info "Invite returned $code"
}

test_proxy() {
  section "Proxy"
  local code
  code=$(curl -so /dev/null -w "%{http_code}" "$PROXY_URL/" 2>/dev/null)
  [[ "$code" =~ ^(200|404|405)$ ]] && pass "Proxy responding (HTTP $code)" || fail "Proxy not responding (HTTP $code)"

  local r
  r=$(curl -sf -X POST "$PROXY_URL/v1/messages" \
    -H "Content-Type: application/json" \
    -H "x-api-key: sk-test-fake-key-pratry" \
    -d '{"model":"claude-3-haiku-20240307","max_tokens":5,"messages":[{"role":"user","content":"hi"}]}' 2>&1 || true)
  echo "$r" | grep -qi "error\|invalid\|authentication\|unauthorized" && \
    pass "Proxy forwards to upstream (expected auth error for fake key)" || \
    info "Proxy response: ${r:0:200}"
}

teardown() {
  local f="$1" p="$2"
  info "Tearing down $p..."
  $COMPOSE_CMD -f "$f" -p "$p" down --volumes --remove-orphans 2>/dev/null || true
  pass "Teardown done"
}

# ──────────────────────────────────────────────────────────────
# TIER RUNNERS
# ──────────────────────────────────────────────────────────────

run_base() {
  section "BASE TIER — Starting"
  local cf="$COMPOSE_DIR/docker-compose.base.yml"
  [[ ! -f "$cf" ]] && { fail "docker-compose.base.yml not found at $cf"; return; }

  export POSTGRES_PASSWORD="pratry_$(openssl rand -hex 8)"
  export JWT_SECRET_KEY="pratry_$(openssl rand -hex 16)"
  export JWT_REFRESH_SECRET_KEY="pratry_$(openssl rand -hex 16)"

  $COMPOSE_CMD -f "$cf" -p "pratry-base" up -d --build 2>&1 | tail -3
  wait_for_backend || { $COMPOSE_CMD -f "$cf" -p "pratry-base" logs --tail=40; teardown "$cf" "pratry-base"; return; }

  test_health; test_auth; test_ingest; test_provenance; test_search
  test_insights; test_export; test_dashboard_page; test_security_headers
  teardown "$cf" "pratry-base"
}

run_plus() {
  section "PLUS TIER — Starting"
  local cf="$COMPOSE_DIR/docker-compose.plus.yml"
  [[ ! -f "$cf" ]] && { fail "docker-compose.plus.yml not found at $cf"; return; }

  export POSTGRES_PASSWORD="pratry_$(openssl rand -hex 8)"
  export JWT_SECRET_KEY="pratry_$(openssl rand -hex 16)"
  export JWT_REFRESH_SECRET_KEY="pratry_$(openssl rand -hex 16)"

  $COMPOSE_CMD -f "$cf" -p "pratry-plus" up -d --build 2>&1 | tail -3
  wait_for_backend || { $COMPOSE_CMD -f "$cf" -p "pratry-plus" logs --tail=60; teardown "$cf" "pratry-plus"; return; }

  test_health; test_auth; test_ingest; test_provenance; test_search
  test_insights; test_export; test_dashboard_page; test_security_headers
  test_team; test_proxy
  teardown "$cf" "pratry-plus"
}

run_max() {
  section "MAX TIER — Starting (Neo4j needs ~60s)"
  local cf="$COMPOSE_DIR/docker-compose.max.yml"
  [[ ! -f "$cf" ]] && { fail "docker-compose.max.yml not found at $cf"; return; }

  export POSTGRES_PASSWORD="pratry_$(openssl rand -hex 8)"
  export NEO4J_PASSWORD="pratry_$(openssl rand -hex 8)"
  export JWT_SECRET_KEY="pratry_$(openssl rand -hex 16)"
  export JWT_REFRESH_SECRET_KEY="pratry_$(openssl rand -hex 16)"

  $COMPOSE_CMD -f "$cf" -p "pratry-max" up -d --build 2>&1 | tail -3

  info "Waiting for Max backend (up to 120s for Neo4j)..."
  for i in $(seq 1 120); do
    curl -sf "$BASE_URL/health" &>/dev/null && { pass "Backend up after ${i}s"; break; }
    sleep 1
  done

  if curl -sf "$BASE_URL/health" &>/dev/null; then
    test_health; test_auth; test_ingest; test_provenance; test_search
    test_insights; test_export; test_dashboard_page; test_security_headers
    test_team; test_proxy

    section "Neo4j (Max only)"
    local code
    code=$(curl -so /dev/null -w "%{http_code}" "http://localhost:7474" 2>/dev/null)
    [[ "$code" =~ ^(200|301|302)$ ]] && pass "Neo4j Browser accessible (HTTP $code)" || fail "Neo4j Browser not reachable (HTTP $code)"

    local h; h=$(curl -sf "$BASE_URL/health" 2>/dev/null)
    echo "$h" | grep -q '"neo4j":true' && pass "Neo4j enabled in health features" || info "Health: $h"
  else
    fail "Max backend did not start within 120s"
    $COMPOSE_CMD -f "$cf" -p "pratry-max" logs --tail=60
  fi

  teardown "$cf" "pratry-max"
}

# ──────────────────────────────────────────────────────────────
# DISPATCH
# ──────────────────────────────────────────────────────────────
case "$TIER" in
  base) run_base ;;
  plus) run_plus ;;
  max)  run_max  ;;
  all)  run_base; run_plus; run_max ;;
  *)    echo "Usage: bash pratry.sh [base|plus|max|all]"; exit 1 ;;
esac

# ──────────────────────────────────────────────────────────────
# SUMMARY
# ──────────────────────────────────────────────────────────────
echo ""
section "RESULT"
if [[ $FAILURES -eq 0 ]]; then
  echo -e "${GREEN}  All tests passed. Ready for deployment.${NC}"
else
  echo -e "${RED}  $FAILURES test(s) FAILED. Fix before deploying.${NC}"
  exit 1
fi
