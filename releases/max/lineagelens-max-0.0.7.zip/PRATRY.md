# LineageLens — Pre-Deployment Verification (pratry)
Run every block below before shipping. Each section shows the expected output.
All commands assume you have `docker`, `docker compose`, `curl`, `python3` installed.

---

## 0. Prerequisites Check

```bash
# Must all return without error
docker --version
docker compose version        # or: docker-compose version
curl --version
python3 --version
node --version
npm --version
openssl version

# Docker daemon must be running
docker info | grep "Server Version"

# Ports must be free
# On Linux/Mac:
lsof -i :8787 || echo "Port 8787 is free"
lsof -i :8788 || echo "Port 8788 is free"
lsof -i :5432 || echo "Port 5432 is free"
lsof -i :7474 || echo "Port 7474 is free"  # Max only
lsof -i :7687 || echo "Port 7687 is free"  # Max only

# On Windows (PowerShell):
netstat -ano | findstr :8787
netstat -ano | findstr :8788
netstat -ano | findstr :5432
```

---

## 1. BASE TIER

### 1a. Unzip and start
```bash
cd lineagelens-base-0.0.7/
bash quickstart.sh
# Expected: "LineageLens Base is ready!" with Backend URL printed
```

### 1b. Health check
```bash
curl -s http://localhost:8787/health | python3 -m json.tool
# Expected:
# {
#   "status": "ok",
#   "app": "LineageLens Base Backend",
#   "version": "0.0.7",
#   "productMode": "base"
# }
```

### 1c. Register a user
```bash
# Schema: username + password + optional workspaceId (NO email, NO full_name)
curl -s -X POST http://localhost:8787/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"TestPass123!","workspaceId":"test-workspace"}' \
  | python3 -m json.tool
# Expected: JSON with "accessToken", "user": {"username": "testuser"}, "workspaceId"
```

### 1d. Login and get token
```bash
# Login also uses JSON body (NOT form-encoded)
curl -s -X POST http://localhost:8787/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"TestPass123!"}' \
  | python3 -m json.tool
# Expected: JSON with "accessToken", "refreshToken", "tokenType": "bearer"

# Save token for remaining tests (key is camelCase "accessToken"):
TOKEN=$(curl -s -X POST http://localhost:8787/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"TestPass123!"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['accessToken'])")
echo "Token: ${TOKEN:0:30}..."
```

### 1e. Ingest a record
```bash
curl -s -X POST http://localhost:8787/ingest \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "agent": "copilot",
    "prompt": "Write a function to hash passwords securely",
    "response": "import bcrypt\ndef hash_password(pwd): return bcrypt.hashpw(pwd.encode(), bcrypt.gensalt())",
    "model": "gpt-4o",
    "workspace_id": "test-workspace",
    "file_path": "src/auth/passwords.py",
    "git_commit": "abc123",
    "risk_level": "HIGH"
  }' | python3 -m json.tool
# Expected: JSON with "id" (UUID) field

RECORD_ID=$(curl -s -X POST http://localhost:8787/ingest \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"agent":"cursor","prompt":"Add error handling","response":"try: pass","model":"gpt-4o","workspace_id":"test-workspace","file_path":"src/main.py","git_commit":"def456","risk_level":"LOW"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
echo "Record ID: $RECORD_ID"
```

### 1f. Fetch provenance record
```bash
curl -s http://localhost:8787/provenance/$RECORD_ID \
  -H "Authorization: Bearer $TOKEN" \
  | python3 -m json.tool
# Expected: Full record JSON with agent, prompt, response, model, file_path fields

# Test 404 for non-existent record
curl -s -o /dev/null -w "HTTP %{http_code}\n" \
  http://localhost:8787/provenance/00000000-0000-0000-0000-000000000000 \
  -H "Authorization: Bearer $TOKEN"
# Expected: HTTP 404
```

### 1g. Dashboard HTML page
```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:8787/dashboard
# Expected: HTTP 200

curl -s http://localhost:8787/dashboard | head -3
# Expected: <!DOCTYPE html> ...
```

### 1h. Security headers
```bash
curl -sI http://localhost:8787/health | grep -i "x-content-type\|x-frame\|referrer"
# Expected:
# x-content-type-options: nosniff
# x-frame-options: DENY
# referrer-policy: no-referrer
```

### 1i. Auth rejection tests
```bash
# No token → must be rejected
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:8787/ingest
# Expected: HTTP 401 or 422

# Bad token → must be rejected
curl -s -o /dev/null -w "HTTP %{http_code}\n" \
  http://localhost:8787/provenance/$RECORD_ID \
  -H "Authorization: Bearer fake.token.here"
# Expected: HTTP 401 or 403
```

### 1j. Export endpoint
```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" \
  http://localhost:8787/export/audit \
  -H "Authorization: Bearer $TOKEN"
# Expected: HTTP 200

# Without auth
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:8787/export/audit
# Expected: HTTP 401 or 422
```

### 1k. Container status
```bash
docker compose -f deploy/docker-compose.base.yml ps
# Expected: all containers showing "running" or "Up"

docker compose -f deploy/docker-compose.base.yml logs --tail=20 backend
# Expected: no ERROR or CRITICAL lines (warnings are OK)
```

### 1l. Tear down base
```bash
docker compose -f deploy/docker-compose.base.yml down --volumes
# Expected: Containers removed, volumes removed
```

---

## 2. PLUS TIER

### 2a. Unzip and start
```bash
cd lineagelens-plus-0.0.7/
bash quickstart.sh
# Expected: "LineageLens Plus is ready!" with Dashboard + Backend + Proxy URLs
```

### 2b. Health check (Plus mode)
```bash
curl -s http://localhost:8787/health | python3 -m json.tool
# Expected:
# {
#   "status": "ok",
#   "productMode": "plus",
#   "features": { "neo4j": false, "vectorSearch": false }
# }
```

### 2c. Run same tests as Base (1c through 1k above)
```bash
# Register, login, ingest, provenance, dashboard, headers, auth rejection, export
# All same commands — see sections 1c–1k
# Reminder: register uses username (not email), login uses JSON body, token key is accessToken
```

### 2d. Team management API
```bash
# First register and login to get TOKEN (see 1c, 1d)

# List team members
curl -s http://localhost:8787/team/members \
  -H "Authorization: Bearer $TOKEN" \
  | python3 -m json.tool
# Expected: JSON array (empty or with current user)

# Invite a new member
curl -s -X POST http://localhost:8787/team/invite \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"email":"newmember@example.com","role":"member"}' \
  | python3 -m json.tool
# Expected: JSON with success/invite details OR 403 if not admin yet

# Bad email rejected
curl -s -o /dev/null -w "HTTP %{http_code}\n" \
  -X POST http://localhost:8787/team/invite \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"email":"not-an-email"}'
# Expected: HTTP 422
```

### 2e. Semantic search
```bash
curl -s -X POST http://localhost:8787/search \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"query":"password hashing authentication","limit":10}' \
  | python3 -m json.tool
# Expected: JSON array of matching records
```

### 2f. Insights dashboard API
```bash
curl -s -X POST http://localhost:8787/insights/dashboard \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"days":30}' \
  | python3 -m json.tool
# Expected: JSON with totals, risk breakdown, recent records
```

### 2g. Proxy is running
```bash
# Proxy must respond on port 8788
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:8788/
# Expected: HTTP 200, 404, or 405 (any response = proxy is up)

# Proxy forwards requests upstream (fake key = upstream auth error, NOT connection refused)
curl -s -X POST http://localhost:8788/v1/messages \
  -H "Content-Type: application/json" \
  -H "x-api-key: sk-test-fake-key" \
  -d '{"model":"claude-3-haiku-20240307","max_tokens":5,"messages":[{"role":"user","content":"hi"}]}'
# Expected: JSON error from Anthropic about invalid API key (proves proxy is forwarding)
```

### 2h. Container status
```bash
docker compose -f deploy/docker-compose.plus.yml ps
# Expected: postgres, backend, proxy all "Up"

# No errors in logs
docker compose -f deploy/docker-compose.plus.yml logs --tail=20 backend
docker compose -f deploy/docker-compose.plus.yml logs --tail=20 proxy
docker compose -f deploy/docker-compose.plus.yml logs --tail=20 postgres
```

### 2i. Tear down Plus
```bash
docker compose -f deploy/docker-compose.plus.yml down --volumes
```

---

## 3. MAX TIER

### 3a. Unzip and start
```bash
cd lineagelens-max-0.0.7/
bash quickstart.sh
# Expected: "LineageLens Max is ready!" with Neo4j URL also listed
# Note: Neo4j takes ~60 seconds to initialize — wait for it
```

### 3b. Health check (Max mode)
```bash
curl -s http://localhost:8787/health | python3 -m json.tool
# Expected:
# {
#   "status": "ok",
#   "productMode": "max",
#   "features": { "neo4j": true, "vectorSearch": true }
# }
```

### 3c. Run all Plus tests (2c through 2g) above
```bash
# All same commands — register, login, ingest, search, insights, proxy
```

### 3d. Neo4j Browser
```bash
# Neo4j Browser must load in browser at:
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:7474
# Expected: HTTP 200 or 301

# Open in browser: http://localhost:7474
# Login: neo4j / <NEO4J_PASSWORD from deploy/.env>
```

### 3e. Neo4j Bolt connection
```bash
# Neo4j Bolt port must be open
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:7687
# Expected: any response (not connection refused)

# If you have cypher-shell installed:
# cypher-shell -a bolt://localhost:7687 -u neo4j -p <your-password> "RETURN 1;"
# Expected: 1 row
```

### 3f. Graph lineage (Max only)
```bash
# After ingesting several records (use ingest commands from 1e), check Neo4j has nodes
# In Neo4j Browser (http://localhost:7474) run:
# MATCH (n) RETURN count(n)
# Expected: count > 0 after ingesting records
```

### 3g. Neo4j container health
```bash
docker compose -f deploy/docker-compose.max.yml ps
# Expected: postgres, neo4j, backend, proxy all "Up (healthy)"

docker compose -f deploy/docker-compose.max.yml logs --tail=30 neo4j
# Expected: "Started" and no FATAL lines

docker compose -f deploy/docker-compose.max.yml logs --tail=20 backend
# Expected: "Neo4j lineage initialized successfully" line
```

### 3h. Tear down Max
```bash
docker compose -f deploy/docker-compose.max.yml down --volumes
```

---

## 4. CLI PACKAGE TEST (npm)

```bash
# Install CLI from the zip's cli/ folder
cd lineagelens-plus-0.0.7/
npm install -g .
# Expected: added 1 package

# Verify CLI is available
lineagelens --version
# Expected: 0.0.7

lineagelens --help
# Expected: help text with start, stop, status, logs subcommands

# Start Plus via CLI
lineagelens start --mode plus
# Expected: same startup as quickstart.sh, dashboard URL printed

# Check status
lineagelens status
# Expected: table showing running containers

# View logs
lineagelens logs
# Expected: streaming log output (Ctrl+C to exit)

# Stop
lineagelens stop --mode plus
# Expected: containers stopped
```

---

## 5. DOCKER IMAGES VERIFICATION

```bash
# Verify images pull correctly (for npm/CLI users who use Hub images)
docker pull karnatipraveen/lineagelens-backend:latest
# Expected: Pull complete, shows digest

docker pull karnatipraveen/lineagelens-proxy:latest
# Expected: Pull complete, shows digest

docker pull pgvector/pgvector:pg16
# Expected: Pull complete

docker pull neo4j:5
# Expected: Pull complete (for Max only)

# Check image sizes (rough sanity check)
docker images | grep -E "lineagelens|pgvector|neo4j"
```

---

## 6. AUTOMATED RUN (runs all tests above in one shot)

```bash
# From the root of the repo (not inside a zip):
bash pratry.sh all     # test all three tiers sequentially
bash pratry.sh base    # test only base
bash pratry.sh plus    # test only plus
bash pratry.sh max     # test only max

# Expected final output:
# All tests passed. Ready for deployment.
```

---

## 7. COMMON ERRORS AND FIXES

| Error | Cause | Fix |
|-------|-------|-----|
| `Port 8787 is already in use` | Previous container still running | `docker ps` then `docker stop <id>` |
| `POSTGRES_PASSWORD not set` | .env file missing | Run `bash quickstart.sh` to generate it |
| `Backend did not start within 60s` | Postgres not ready | Check `docker compose logs postgres` |
| `HTTP 401` on all endpoints | Token expired | Re-login and get new TOKEN |
| `KeyError: 'access_token'` | Wrong key — response uses camelCase | Use `['accessToken']` not `['access_token']` |
| `"email" not allowed` on register | Wrong field name | Use `username` not `email`; no `full_name` field |
| `422` on login with form data | Wrong Content-Type | Login takes JSON body, not `application/x-www-form-urlencoded` |
| `HTTP 403` on team endpoints | Not an admin user | First registered user is admin |
| `neo4j exited (137)` | Not enough memory | Increase Docker Desktop memory to 4GB+ |
| `cypher-shell auth failure` | Wrong NEO4J_PASSWORD | Check `deploy/.env` for actual password |
| `Proxy returns connection refused` | Proxy container not running | `docker compose logs proxy` |
| `Dashboard 404` | Static file missing | Check `backend/app/static/dashboard.html` exists |
| `Image pull failed` | Not logged into Docker Hub | `docker login` first |
| `npm: command not found` | Node not installed | Install Node 18+ from nodejs.org |
