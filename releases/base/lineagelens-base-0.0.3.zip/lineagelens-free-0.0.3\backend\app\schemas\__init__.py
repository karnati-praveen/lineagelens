"""Pydantic schema package."""
